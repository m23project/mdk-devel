#!perl -w
#
# Conf -- configured path names and such.
#   Copyright (C) 2005  Erik van Konijnenburg
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
#
# You can get and set configuration items by name,
# with the following restrictions:
# - only get and set known keys
# - after first get, no further set is allowed.
#
# Defaults are packaged as subs, so that you can change
# one setting and have the change ripple through in other
# settings.
#
use strict;
use warnings;
use Base;
package Conf;

sub get($);

#
# Default values for configuration; if there is no default,
# it's not a known parameter, and you cannot modify it.
#
my $defaults = {
	version		=> sub { my $v = `uname -r`; chomp $v; $v; },
	libModules	=> sub { "/lib/modules"; },
	kernConf	=> sub { "/boot/config-"
				. get('version'); },
	modDep		=> sub { get('libModules')
				. '/' . get('version')
				. '/modules.dep'; },
	usbMap		=> sub { get('libModules')
				. '/' . get('version')
				. '/modules.usbmap'; },
	pciMap		=> sub { get('libModules')
				. '/' . get('version')
				. '/modules.pcimap'; },
	ofMap		=> sub { get('libModules')
				. '/' . get('version')
				. '/modules.ofmap'; },
	ccwMap		=> sub { get('libModules')
				. '/' . get('version')
				. '/modules.ccwmap'; },
	modDir		=> sub { get('libModules')
				. '/' . get('version')
				. '/kernel'; },
	sysFs		=> sub { "/sys"; },
	procFs		=> sub { "/proc"; },
	dev		=> sub { "/dev"; },
	fstab		=> sub { "/etc/fstab"; },
	crypttab	=> sub { "/etc/crypttab"; },
	hotplug		=> sub { "/etc/hotplug"; },
	appVersion	=> sub { "0.0.12"; },
	auxDir		=> sub { "/usr/lib/yaird/exec"; },
	cfgDir		=> sub { "/etc/yaird"; },
};


my $overrides = {};		# config values where default is overridden,
				# presumably via command line.
my $used = {};			# if a key exists, the config value has
				# been used, and it no longer can be changed.

sub get ($) {
	my ($key) = @_;
	my $dflt = $defaults->{$key};
	Base::assert (defined ($dflt));
	$used->{$key}++;
	my $ovr = $overrides->{$key};
	if (defined ($ovr)) {
		return $ovr;
	}
	return &{$dflt}();
}

sub set ($$) {
	my ($key, $value) = @_;
	my $dflt = $defaults->{$key};
	Base::assert (defined ($dflt));
	Base::assert (! defined ($used->{$key}));
	$overrides->{$key} = $value;
}

1;
