-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 26. Jun 2017 um 23:29
-- Server-Version: 5.5.55-0+deb8u1
-- PHP-Version: 5.6.30-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `m23`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `clients`
--

CREATE TABLE `clients` (
  `id` int(9) UNSIGNED NOT NULL,
  `client` longtext NOT NULL,
  `office` longtext NOT NULL,
  `name` varchar(40) NOT NULL DEFAULT '',
  `familyname` varchar(40) NOT NULL DEFAULT '',
  `eMail` longtext NOT NULL,
  `mac` varchar(12) NOT NULL,
  `ip` varchar(40) NOT NULL DEFAULT '',
  `netmask` varchar(40) NOT NULL DEFAULT '',
  `gateway` varchar(40) NOT NULL DEFAULT '',
  `dns1` varchar(40) NOT NULL DEFAULT '',
  `dns2` varchar(40) NOT NULL DEFAULT '',
  `firstpw` varchar(40) NOT NULL DEFAULT '',
  `rootPassword` varchar(40) NOT NULL DEFAULT '',
  `memory` varchar(40) NOT NULL DEFAULT '',
  `hd` varchar(40) NOT NULL DEFAULT '',
  `partitions` longtext NOT NULL,
  `CFDiskTemp` longtext NOT NULL,
  `cpu` longtext NOT NULL,
  `MHz` longtext NOT NULL,
  `netcards` longtext NOT NULL,
  `graficcard` longtext NOT NULL,
  `soundcard` longtext NOT NULL,
  `isa` longtext NOT NULL,
  `dmi` longtext NOT NULL,
  `dhcpBootimage` varchar(40) NOT NULL DEFAULT '',
  `installdate` int(10) NOT NULL DEFAULT '0',
  `lastmodify` int(10) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `language` varchar(5) NOT NULL,
  `options` longtext NOT NULL,
  `vmRunOnHost` int(9) DEFAULT '-1',
  `vmSoftware` int(11) DEFAULT '0',
  `vmRole` tinyint(1) NOT NULL DEFAULT '0',
  `vmVisualPassword` varchar(40) NOT NULL,
  `vmVisualURL` varchar(255) NOT NULL,
  `keyValueStore` longtext,
  `autoUpdate_lastAttempt` int(10) DEFAULT NULL,
  `autoUpdate_gotJob` tinyint(1) NOT NULL,
  `autoUpdate_fails` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='New Table by Daniel';

--
-- Daten für Tabelle `clients`
--

INSERT INTO `clients` (`id`, `client`, `office`, `name`, `familyname`, `eMail`, `mac`, `ip`, `netmask`, `gateway`, `dns1`, `dns2`, `firstpw`, `rootPassword`, `memory`, `hd`, `partitions`, `CFDiskTemp`, `cpu`, `MHz`, `netcards`, `graficcard`, `soundcard`, `isa`, `dmi`, `dhcpBootimage`, `installdate`, `lastmodify`, `status`, `language`, `options`, `vmRunOnHost`, `vmSoftware`, `vmRole`, `vmVisualPassword`, `vmVisualURL`, `keyValueStore`, `autoUpdate_lastAttempt`, `autoUpdate_gotJob`, `autoUpdate_fails`) VALUES
(935, 'mint17', '', 'test', '', '', '080027A53B56', '192.168.1.94', '255.255.255.0', '192.168.1.5', '85.88.19.10', '83.169.185.225', 'test', '$1$nEFI2NHn$ptuJg/Rg2tH8KmMm0.sAg.', '748', '', 'dev0_path###dev0_size###dev0part0_nr###dev0part0_start###dev0part0_end###dev0part0_type###dev0part0_fs###dev0part1_nr###dev0part1_start###dev0part1_end###dev0part1_type###dev0part1_fs###dev0_partamount###dev_amount###/dev/sda###8590###1###2.10###8216###primary###ext4###2###8217###8590###primary###linux-swap(v1)###2###1', 'a:5:{s:18:\"wantedPartitioning\";a:1:{i:0;a:4:{s:3:\"dev\";s:8:\"/dev/sda\";s:4:\"size\";s:4:\"8590\";i:0;a:5:{s:2:\"nr\";s:1:\"1\";s:5:\"start\";s:4:\"2.10\";s:3:\"end\";s:4:\"8216\";s:4:\"type\";s:7:\"primary\";s:2:\"fs\";s:4:\"ext4\";}i:1;a:5:{s:2:\"nr\";s:1:\"2\";s:5:\"start\";s:4:\"8217\";s:3:\"end\";s:4:\"8590\";s:4:\"type\";s:7:\"primary\";s:2:\"fs\";s:14:\"linux-swap(v1)\";}}}s:14:\"partitionSteps\";a:6:{i:0;a:6:{s:7:\"command\";s:3:\"add\";s:3:\"dev\";s:8:\"/dev/sda\";s:5:\"start\";i:2;s:3:\"end\";i:8216;s:4:\"type\";s:7:\"primary\";s:5:\"pPart\";i:1;}i:1;a:3:{s:7:\"command\";s:5:\"bflag\";s:3:\"dev\";s:8:\"/dev/sda\";s:5:\"pPart\";i:1;}i:2;a:3:{s:7:\"command\";s:6:\"format\";s:3:\"dev\";s:9:\"/dev/sda1\";s:2:\"fs\";s:4:\"ext4\";}i:3;a:6:{s:7:\"command\";s:3:\"add\";s:3:\"dev\";s:8:\"/dev/sda\";s:5:\"start\";i:8217;s:3:\"end\";i:8589;s:4:\"type\";s:7:\"primary\";s:5:\"pPart\";i:2;}i:4;a:3:{s:7:\"command\";s:6:\"format\";s:3:\"dev\";s:9:\"/dev/sda2\";s:2:\"fs\";s:10:\"linux-swap\";}i:5;a:3:{s:7:\"command\";s:5:\"bflag\";s:3:\"dev\";s:8:\"/dev/sda\";s:5:\"pPart\";s:1:\"1\";}}s:4:\"undo\";a:1:{i:0;a:2:{s:2:\"wp\";a:1:{i:0;a:4:{s:3:\"dev\";s:8:\"/dev/sda\";s:4:\"size\";s:4:\"8590\";i:0;a:5:{s:2:\"nr\";i:1;s:5:\"start\";i:2;s:3:\"end\";i:8216;s:4:\"type\";s:7:\"primary\";s:2:\"fs\";s:4:\"ext4\";}i:1;a:5:{s:2:\"nr\";i:2;s:5:\"start\";i:8217;s:3:\"end\";i:8589;s:4:\"type\";s:7:\"primary\";s:2:\"fs\";s:10:\"linux-swap\";}}}s:2:\"ps\";a:6:{i:0;a:6:{s:7:\"command\";s:3:\"add\";s:3:\"dev\";s:8:\"/dev/sda\";s:5:\"start\";i:2;s:3:\"end\";i:8216;s:4:\"type\";s:7:\"primary\";s:5:\"pPart\";i:1;}i:1;a:3:{s:7:\"command\";s:5:\"bflag\";s:3:\"dev\";s:8:\"/dev/sda\";s:5:\"pPart\";i:1;}i:2;a:3:{s:7:\"command\";s:6:\"format\";s:3:\"dev\";s:9:\"/dev/sda1\";s:2:\"fs\";s:4:\"ext4\";}i:3;a:6:{s:7:\"command\";s:3:\"add\";s:3:\"dev\";s:8:\"/dev/sda\";s:5:\"start\";i:8217;s:3:\"end\";i:8589;s:4:\"type\";s:7:\"primary\";s:5:\"pPart\";i:2;}i:4;a:3:{s:7:\"command\";s:6:\"format\";s:3:\"dev\";s:9:\"/dev/sda2\";s:2:\"fs\";s:10:\"linux-swap\";}i:5;a:3:{s:7:\"command\";s:5:\"bflag\";s:3:\"dev\";s:8:\"/dev/sda\";s:5:\"pPart\";s:1:\"1\";}}}}s:22:\"partitionStepsForShift\";a:6:{i:0;a:6:{s:7:\"command\";s:3:\"add\";s:3:\"dev\";s:8:\"/dev/sda\";s:5:\"start\";i:2;s:3:\"end\";i:8216;s:4:\"type\";s:7:\"primary\";s:5:\"pPart\";i:1;}i:1;a:3:{s:7:\"command\";s:5:\"bflag\";s:3:\"dev\";s:8:\"/dev/sda\";s:5:\"pPart\";i:1;}i:2;a:3:{s:7:\"command\";s:6:\"format\";s:3:\"dev\";s:9:\"/dev/sda1\";s:2:\"fs\";s:4:\"ext4\";}i:3;a:6:{s:7:\"command\";s:3:\"add\";s:3:\"dev\";s:8:\"/dev/sda\";s:5:\"start\";i:8217;s:3:\"end\";i:8589;s:4:\"type\";s:7:\"primary\";s:5:\"pPart\";i:2;}i:4;a:3:{s:7:\"command\";s:6:\"format\";s:3:\"dev\";s:9:\"/dev/sda2\";s:2:\"fs\";s:10:\"linux-swap\";}i:5;a:3:{s:7:\"command\";s:5:\"bflag\";s:3:\"dev\";s:8:\"/dev/sda\";s:5:\"pPart\";s:1:\"1\";}}s:5:\"fstab\";a:0:{}}', 'Intel(R) Core(TM) i3-4330 CPU @ 3.50GHz', '3491.515', '00:03.0 Ethernet controller: Intel Corporation 82540EM Gigabit Ethernet Controller (rev 02)', '00:02.0 VGA compatible controller: InnoTek Systemberatung GmbH VirtualBox Graphics Adapter', '00:05.0 Multimedia audio controller: Intel Corporation 82801AA AC\'97 Audio Controller (rev 01)', '', '# dmidecode 2.11\nSMBIOS 2.5 present.\n10 structures occupying 449 bytes.\nTable at 0x000E1000.\n\nHandle 0x0000, DMI type 0, 20 bytes\nBIOS Information\n	Vendor: innotek GmbH\n	Version: VirtualBox\n	Release Date: 12/01/2006\n	Address: 0xE0000\n	Runtime Size: 128 kB\n	ROM Size: 128 kB\n	Characteristics:\n		ISA is supported\n		PCI is supported\n		Boot from CD is supported\n		Selectable boot is supported\n		8042 keyboard services are supported (int 9h)\n		CGA/mono video services are supported (int 10h)\n		ACPI is supported\n\nHandle 0x0001, DMI type 1, 27 bytes\nSystem Information\n	Manufacturer: innotek GmbH\n	Product Name: VirtualBox\n	Version: 1.2\n	Serial Number: 0\n	UUID: 4D3EEC38-6B31-4D09-B919-C67373A3D2AC\n	Wake-up Type: Power Switch\n	SKU Number: Not Specified\n	Family: Virtual Machine\n\nHandle 0x0008, DMI type 2, 15 bytes\nBase Board Information\n	Manufacturer: Oracle Corporation\n	Product Name: VirtualBox\n	Version: 1.2\n	Serial Number: 0\n	Asset Tag: Not Specified\n	Features:\n		Board is a hosting board\n	Location In Chassis: Not Specified\n	Chassis Handle: 0x0003\n	Type: Motherboard\n	Contained Object Handles: 0\n\nHandle 0x0003, DMI type 3, 13 bytes\nChassis Information\n	Manufacturer: Oracle Corporation\n	Type: Other\n	Lock: Not Present\n	Version: Not Specified\n	Serial Number: Not Specified\n	Asset Tag: Not Specified\n	Boot-up State: Safe\n	Power Supply State: Safe\n	Thermal State: Safe\n	Security Status: None\n\nHandle 0x0007, DMI type 126, 42 bytes\nInactive\n\nHandle 0x0005, DMI type 126, 15 bytes\nInactive\n\nHandle 0x0006, DMI type 126, 28 bytes\nInactive\n\nHandle 0x0002, DMI type 11, 7 bytes\nOEM Strings\n	String 1: vboxVer_4.3.26\n	String 2: vboxRev_98988\n\nHandle 0x0008, DMI type 128, 8 bytes\nOEM-specific Type\n	Header and Data:\n		80 08 08 00 23 35 35 00\n\nHandle 0xFEFF, DMI type 127, 4 bytes\nEnd Of Table', 'pxe', 1430757350, 1430760770, 2, 'de', 'efiPart?getSystemtimeByNTP?addNewLocalLogin?installPrinter?arch?ldaptype?ldapserver?login?packageProxy?packagePort?userID?groupID?timeZone?bootloader?nfshomeserver?netRootPwd?newgroup?uefiActive?instPart?swapPart?mbrPart?desktop?distr?release?packagesource?kernel?disableSSLCertCheck?disableSudoRootLogin?installX2goserver?m23cupsadminPW??yes?yes?yes?amd64?none?m23-LDAP?test?192.168.1.77?2323?2018?2018?Europe/Berlin?grub??018db1?default?0?/dev/sda1?/dev/sda2?/dev/sda?Mint17Cinnamon?ubuntu?trusty?Linux Mint 17 Qiana?linux-image-generic?0?0?0?286d687e6a292e8386f763c461910d30', -1, 0, 0, '', '', NULL, 0, 0, 0);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(9) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1029;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
